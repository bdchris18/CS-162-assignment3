#ifndef SLOTH_H
#define SLOTH_H

#include <string>
#include "animal.h"


class Sloth : public Animal{
public:
    Sloth();
    ~Sloth();
};

#endif