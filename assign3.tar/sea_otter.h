#ifndef SEA_OTTER_H
#define SEA_OTTER_H

#include <string>
#include "animal.h"


class Sea_otter : public Animal{
public:
    Sea_otter();
    ~Sea_otter();
};

#endif