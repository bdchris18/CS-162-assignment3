#ifndef MONKEY_H
#define MONKEY_H

#include <string>
#include "animal.h"


class Monkey : public Animal{
public:
    Monkey();
    ~Monkey();
};

#endif